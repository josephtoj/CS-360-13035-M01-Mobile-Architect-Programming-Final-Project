package com.example.josephtojweighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button openWeights = findViewById(R.id.buttonOpenWeights);
        Button openSms = findViewById(R.id.buttonOpenSms);

        if (openWeights != null) {
            openWeights.setOnClickListener(v ->
                    startActivity(new Intent(this, WeightsActivity.class)));
        }
        if (openSms != null) {
            openSms.setOnClickListener(v ->
                    startActivity(new Intent(this, SmsPermissionActivity.class)));
        }

        // Login/Create buttons intentionally have no logic yet (Project Three will add it)
        // This keeps the UI-only requirement intact.
    }
}
