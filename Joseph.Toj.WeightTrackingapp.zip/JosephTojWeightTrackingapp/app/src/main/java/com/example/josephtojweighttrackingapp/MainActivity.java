package com.example.josephtojweighttrackingapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        if (buttonSayHello != null) buttonSayHello.setEnabled(false);

        if (nameText != null) {
            nameText.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                    boolean hasText = s != null && !s.toString().trim().isEmpty();
                    if (buttonSayHello != null) buttonSayHello.setEnabled(hasText);
                }
                @Override public void afterTextChanged(Editable s) { }
            });
        }
    }

    // Required signature for android:onClick
    public void SayHello(View view) {
        if (nameText == null) return;
        CharSequence cs = nameText.getText();
        if (cs == null) return;

        String name = cs.toString().trim();
        if (name.isEmpty()) return;

        if (textGreeting == null) {
            textGreeting = findViewById(R.id.textGreeting);
            if (textGreeting == null) return;
        }
        textGreeting.setText(getString(R.string.greeting, name));
    }
}
