package com.example.josephtojweighttrackingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsPermissionActivity extends AppCompatActivity {

    private TextView textStatus;

    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    textStatus.setText(getString(R.string.sms_status_granted));
                } else {
                    textStatus.setText(getString(R.string.sms_status_denied));
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        textStatus = findViewById(R.id.textSmsStatus);
        Button check = findViewById(R.id.buttonCheckPermission);
        Button request = findViewById(R.id.buttonRequestPermission);

        check.setOnClickListener(v -> updateStatus());
        request.setOnClickListener(v -> requestSmsPermission.launch(Manifest.permission.SEND_SMS));

        updateStatus();
    }

    private void updateStatus() {
        boolean granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        textStatus.setText(granted ? getString(R.string.sms_status_granted)
                : getString(R.string.sms_status_denied));
    }
}
