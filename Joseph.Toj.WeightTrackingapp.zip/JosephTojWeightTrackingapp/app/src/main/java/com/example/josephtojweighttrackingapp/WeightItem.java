package com.example.josephtojweighttrackingapp;

public class WeightItem {
    public final String date;
    public final String weight;
    public WeightItem(String date, String weight) {
        this.date = date;
        this.weight = weight;
    }
}
