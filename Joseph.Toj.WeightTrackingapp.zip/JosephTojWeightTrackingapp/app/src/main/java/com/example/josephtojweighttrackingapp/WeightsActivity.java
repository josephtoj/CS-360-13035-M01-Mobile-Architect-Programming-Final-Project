package com.example.josephtojweighttrackingapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class WeightsActivity extends AppCompatActivity {

    private final List<WeightItem> items = new ArrayList<>();
    private WeightAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weights);

        // Sample rows to visualize the grid
        items.add(new WeightItem("2025-08-15", "182.4"));
        items.add(new WeightItem("2025-08-16", "181.9"));
        items.add(new WeightItem("2025-08-17", "181.2"));

        RecyclerView rv = findViewById(R.id.recyclerWeights);
        // 1 column list visually aligned with headers; feel free to change to true grid if desired
        rv.setLayoutManager(new GridLayoutManager(this, 1));
        adapter = new WeightAdapter(items);
        rv.setAdapter(adapter);

        EditText editDate = findViewById(R.id.editDate);
        EditText editWeight = findViewById(R.id.editWeight);
        findViewById(R.id.buttonAddWeight).setOnClickListener(v -> {
            String date = editDate.getText() != null ? editDate.getText().toString().trim() : "";
            String weight = editWeight.getText() != null ? editWeight.getText().toString().trim() : "";
            if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weight)) {
                Toast.makeText(this, "Enter date and weight", Toast.LENGTH_SHORT).show();
                return;
            }
            items.add(new WeightItem(date, weight));
            adapter.notifyItemInserted(items.size() - 1);
            editDate.setText("");
            editWeight.setText("");
        });
    }
}
